/*
	BlackBear Class
*/
#include <iostream>
#include "blackbear.h"

using namespace std;

BlackBear::BlackBear() : Animal(){
  //  cout << "Default sealion constructor called" << endl;
    cost = 15000;
    this->set_cost(cost);
    a.set_age(0);

}

BlackBear::BlackBear(double aAge) : Animal(aAge){
  //  cout << "Alternate sealion constructor called" << endl;
    cost = 15000;
    this->set_cost(cost);
    a.set_age(aAge);
}

int BlackBear::sickcost() {
    if (a.isAdult()==true) { //IS ADULT
        return cost/2;
    } else if (a.isBaby() == true){ //IS BABY
        return cost;
    } else { //IS TEEN
        return cost/2;
    }
}

int BlackBear::revenue() {
    if (a.isAdult()== true) { //IS ADULT
        return 1500;
    } else if (a.isBaby() == true){ //IS BABY
        return 3000;
    } else { //IS TEEN
        return 1500;
    }
}

BlackBear::~BlackBear() {
   // cout << "BlackBear Destructor" << endl;
} 
/*
	Animal Class
*/
#include <iostream>
#include "animal.h"

using namespace std;

Animal::Animal(double aAge) {
	//cout << "Alternate animal constructor called" << endl;
	//name = input_name;
    this->age = aAge;
    n_babies = 0;
    month = 0;
    cost = 0;
}

Animal::Animal() {
	//cout << "Default animal constructor called" << endl;
	//this->name = "Specimen Unknown";
    age = 0;
    n_babies = 0;
    month = 0;
    cost = 0;
}

Animal::~Animal() {
   // cout << "Animal Destructor" << endl;
}

/*************************************************************************************************************************************
** Function: Copy constructor
** Description: Tells program how to copy object
** Parameters: const Animal& old_deck
** Pre-conditions: const Animal& old_deck
** Post-conditions: none
*************************************************************************************************************************************/
//Animal::Animal(const Animal& old_animal){
    //cout << "Animal copy constructor!\n";
  /*  this->n_cards = old_deck.n_cards;
    delete [] cards;
    cards = new Card[this->n_cards];
    for(int i = 0; i<n_cards; i++) {
        cards[i] = old_deck.cards[i];
    } */
//}  

/*************************************************************************************************************************************
** Function: Assignment Operator
** Description: Tells program how to copy object
** Parameters: const Hand& old_deck
** Pre-conditions: const Hand& old_deck
** Post-conditions: return *this
*************************************************************************************************************************************/
//Animal& Animal::operator=(const Animal& old_deck){
  //  cout << "AOO!\n";
   /* if(this != &old_deck){
        delete [] cards;
        this-> n_cards = old_deck.n_cards;
        cards = new Card[this->n_cards];

        for(int i = 0; i<n_cards; i++) {
            cards[i] = old_deck.cards[i];
        }
    } */
  //  return *this;
//} 

void Animal::bump_age() {
    month++;
    if (month%12 == 0) {
        this->age = age+1;
    }
}

bool Animal::isAdult() {
    if (age >= 4) {
        return true;
    }else {
        return false;
    }
    return false;
}

bool Animal::isBaby() {
    if (age <= 0.6) {
        return true;
    }else {
        return false;
    }
    return false;
}

bool Animal::isTeen() {
    if (age > 0.6 && age < 4) {
        return true;
    }else {
        return false;
    }
    return false;
} 

int Animal::get_age() {
	return age;
}

void Animal::set_age(int age){
    this->age = age;
}

int Animal::get_cost() {
	return cost;
}

void Animal::set_cost(int cost){
    this->cost = cost;
}

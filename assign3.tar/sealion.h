/*
	SeaLion Class
*/
#ifndef SEALION_H
#define SEALION_H

#include <iostream>
#include "animal.h"

using namespace std;

class SeaLion : public Animal {
public:
	SeaLion();
    SeaLion(double);  //inherits age from animal
    int sickcost(); //determines cost after inheritance from animal
    int revenue(); //determines revenue after inheritance from animal
    int extrarevenue();
    ~SeaLion();
    Animal a;
    //Animal makeBaby();

private:
    int cost;
    static const int DEFAULT_ADULT_AGE = 4;
    static const int DEFAULT_BABY_AGE = 0;
    
};
#endif
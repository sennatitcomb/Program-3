/*
	Zoo Class
*/
#include <iostream>
#include "zoo.h"

using namespace std;

Zoo::Zoo(){
    srand (time(NULL));
    //cout << "Default zoo constructor called" << endl;
    month = 0;
    bank = 100000;
    n_sealions = 0;
    sealions = nullptr;
    n_tigers = 0;
    tigers = nullptr;
    n_bears = 0;
    bears = nullptr;
    n_adults = 0;
    n_babies = 0;
    n_teens = 0;
}

bool Zoo::bankrupt() {
    if (bank >= 0) {
        return false;
    } else{
        cout << "You spent more money than you had and went bankrupt. Game Over." << endl;
        return true;
    }
    return false;
}

void Zoo::playgame() {
    bool gameover = false;
    int x = 0;
    while ((gameover == false) && (bankrupt()==false)) {
        userinfo();
        random();
        revenue();
        buyanimals();
        feed();
        increaseage();
        bool valid = false;
        while (valid == false) {
            cout << "Would you like to keep playing or quit? Enter 0 to keep playing and 1 to quit." << endl;
            cin >> x;
            cin.clear();
            cin.ignore(1000,'\n');
            if (x == 1) {
                gameover = true;
                valid = true;
            } else if (x == 0) {
                valid = true;
            }
        }
    } 
}

void Zoo::userinfo() {
    cout << "You have $" << bank << " in your bank." << endl;
    adults();
    cout << "You have " << n_adults << " adults." << endl; //CHANGE TO ADULTS AND BABIES
    babies();
    cout << "You have " << n_babies << " babies." << endl;
    printf("\x1B[34mMonth: \033[0m");
    cout << month << endl;
    month++;
}

void Zoo::adults() {
    n_adults = 0;
    for (int i = 0; i<n_sealions; i++) {
        if (sealions[i].isAdult() == true) {
            n_adults++;
        } 
    }
    for (int j = 0; j<n_tigers; j++) {
        if (tigers[j].isAdult() == true) {
            n_adults++;
        }
    }
    for (int k = 0; k<n_bears; k++) {
        if (bears[k].isAdult() == true) {
            n_adults++;
        }
    }
}


void Zoo::babies() {
    n_babies = 0;
    for (int i = 0; i<n_sealions; i++) {
        if (sealions[i].isBaby() == true) {
            n_babies++;
        } 
    }
    for (int j = 0; j<n_tigers; j++) {
        if (tigers[j].isBaby() == true) {
            n_babies++;
        }
    }
    for (int k = 0; k<n_bears; k++) {
        if (bears[k].isBaby() == true) {
            n_babies++;
        }
    }
}


void Zoo::teens() {
    n_teens = 0;
    for (int i = 0; i<n_sealions; i++) {
        if (sealions[i].isTeen() == true) {
            n_teens++;
        } 
    }
    for (int j = 0; j<n_tigers; j++) {
        if (tigers[j].isTeen() == true) {
            n_teens++;
        }
    }
    for (int k = 0; k<n_bears; k++) {
        if (bears[k].isTeen() == true) {
            n_teens++;
        }
    }
} 

void Zoo::random() {
    if (n_adults >= 1 || n_babies >= 1 || n_teens>= 1) {
        int x = rand()%4+1;
        if (x == 1) {
            cout << "One animal has gotten sick." << endl;
            sick();
        }else if (x == 2) {
            cout << "An animal has given birth." << endl;
            baby();
        }else if (x == 3) {
            cout << "There has been a boom in zoo attendance!" << endl;
            boom();
        }else {
            cout << "No special event has occured." << endl;
        } 
    } else {
        cout << "You have no animals so no events occured." << endl;
    }
    
}

void Zoo::sick() {
    bool found = false;
    while (found == false) {
        int x = rand()%3+1;
        if (x == 1) {
            if (n_sealions >= 1) {
                sicklion();
                found = true;
            } 
        }else if (x==2) {
            if (n_tigers >= 1) {
                sicktiger();
                found = true;
            }
        }else {
            if (n_bears >= 1) {
                sickbear();
                found = true;
            }
        }
    
    }
}

void Zoo::sicklion() {
    cout << "A Sea Lion got sick!" << endl;
    int y = rand()%(n_sealions); 
    if (bank > sealions[y].sickcost()) {
        cout << "You have paid to heal your animal!" << endl;
        decreasemoney(sealions[y].sickcost());
    } else {
        cout << "You don't have enough money to heal the sick animal! It has died." << endl;
        removesealion(y);
    }
    //printlion();
}

void Zoo::sicktiger() {
    cout << "A Tiger got sick!" << endl;
    int y = rand()%(n_tigers); 
    if (bank > tigers[y].sickcost()) {
        cout << "You have paid to heal your animal!" << endl;
        decreasemoney(tigers[y].sickcost());
    } else {
        cout << "You don't have enough money to heal the sick animal! It has died." << endl;
        removetiger(y);
    }
    //printtiger();
}

void Zoo::sickbear() {
    cout << "A Bear got sick!" << endl;
    int y = rand()%(n_bears); 
    if (bank > bears[y].sickcost()) {
        cout << "You have paid to heal your animal!" << endl;
        decreasemoney(bears[y].sickcost());
    } else {
        cout << "You don't have enough money to heal the sick animal! It has died." << endl;
        removebear(y);
    }
    //printbear();
}


int Zoo::decreasemoney(int x) {
    bank = bank - x;
    cout << "You have $" << bank << " left in your bank." << endl;
    return bank; 
}

void Zoo::baby() {
    bool found = false;
    while (found == false) {
        int x = rand()%3+1;
        if (x == 1) {
            if (checksadult() == true) {
                cout << "A Sea Lion had a baby!" << endl;
                makesealion(1, 0);
                //printlion();
                found = true;
            } 
        }else if (x==2) {
            if (checktadult() == true) {
                cout << "A Tiger had 3 babies!" << endl;
                maketiger(3, 0);
                //printtiger();
                found = true;
            } 
            
        }else {
            if (checkbadult() == true) {
                cout << "A Bear had 2 babies!" << endl;
                makebear(2, 0);
                //printbear();
                found = true;
            }
        }
    
    }
    
   
}

void Zoo::buyanimals() {
    int x = 0;
    cout << "How many animals would you like to buy? Enter 0, 1, or 2." << endl;
    cin >> x;
    cin.clear();
    cin.ignore(1000,'\n');
    if ( (x>=1) && (x<=2)) {
        species(x);  
    } else if ((x!=0) && (x!=1) && (x!=2)){
        cout << "You did not enter a valid choice!" << endl;
        buyanimals();
    }
   

} 

void Zoo::species(int x) {
    int y = 0;
    cout << "What species would you like to buy? Enter 0 for sea lions, 1 for tigers, and 2 for black bears." << endl;
    cin >> y;
    cin.clear();
    cin.ignore(1000,'\n');
    if (y == 0) {
        for (int i = 0; i < x; i++) {
            decreasemoney(800);
        } 
        makesealion(x, 4);
        //printlion();
        //SeaLion
    } else if (y == 1) {
        for (int i = 0; i < x; i++) {
            decreasemoney(15000);
        } 
        maketiger(x, 4);
        //printtiger();
        //Tiger
    } else {
        for (int i = 0; i < x; i++) {
            decreasemoney(6000);
        } 
        makebear(x, 4);
        //printbear();
        //Bear
    }
}

void Zoo::makesealion(int x, double age){
    for (int y = 0; y<x; y++) {
        SeaLion* newsealions = new SeaLion[++n_sealions];
        newsealions[n_sealions-1] = SeaLion(age);
        for(int i = 0; i<n_sealions-1; i++) {
            newsealions[i] = sealions[i];
        }
    //}
    if (n_sealions >= 1)
        delete [] sealions;
    sealions = newsealions;
    }
}

void Zoo::maketiger(int x, double age){
    for (int y = 0; y<x; y++) {
        Tiger* newtigers = new Tiger[++n_tigers];
        newtigers[n_tigers-1] = Tiger(age);
        for(int i = 0; i<n_tigers-1; i++) {
            newtigers[i] = tigers[i];
        }
    //}
    if (n_tigers >= 1)
        delete [] tigers;
    tigers = newtigers;
    }
}

void Zoo::makebear(int x, double age){
    for (int y = 0; y<x; y++) {
        BlackBear* newbears = new BlackBear[++n_bears];
        newbears[n_bears-1] = BlackBear(age);
        for(int i = 0; i<n_bears-1; i++) {
            newbears[i] = bears[i];
        }
    //}
    if (n_bears >= 1)
        delete [] bears;
    bears = newbears;
    }
}

void Zoo::increaseage(){ //EVERY MONTH
    for (int y = 0; y<n_sealions; y++) {
        sealions[y].bump_age();
    }
    for (int i = 0; i<n_tigers; i++) {
        tigers[i].bump_age();
    }
    for (int j = 0; j<n_bears; j++) {
        bears[j].bump_age();
    }
    //DO FOR TIGERS AND BEARS
}

bool Zoo::checksadult(){
    for (int y = 0; y<n_sealions; y++) {
        if (sealions[y].get_age() >= 4) {
            return true;
            break;
        } 
    }
    return false;
} 

bool Zoo::checktadult(){
    for (int y = 0; y<n_tigers; y++) {
        if (sealions[y].get_age() >= 4) {
            return true;
            break;
        } 
    }
    return false;
} 

bool Zoo::checkbadult(){
    for (int y = 0; y<n_bears; y++) {
        if (sealions[y].get_age() >= 4) {
            return true;
            break;
        } 
    }
    return false;
} 


void Zoo::printlion() {
     for (int y = 0; y<n_sealions; y++) {
        cout << "S:" << sealions[y].get_age();
    }
} 

void Zoo::printtiger() {
     for (int y = 0; y<n_tigers; y++) {
        cout << "T:" << tigers[y].get_age();
    }
}

void Zoo::printbear() {
     for (int y = 0; y<n_sealions; y++) {
        cout << "B:" << bears[y].get_age();
    }
}

void Zoo::feed() {
    double food = 80;
    double x = (rand()%40 + 80);
    double deduction = 0;
    x = x /100;
    food = food * x;
    //cout << "Food base cost is " << food << endl;
    //PER ANIMAL
    deduction = deduction + n_sealions*food;
    deduction = deduction + n_tigers*(5*food);
    deduction = deduction + n_bears*(3*food);
    bank = bank - deduction;
    cout << "You have paid $" << deduction << " to feed your animals." << endl;
    cout << "You have $" <<bank << " left." << endl;
    //Tigers have a monthly food cost of 5 times the base food cost.
    //Black Bears have a monthly food cost of 3 times the base food cost.
    //Sea Lions have a monthly food cost equal to the base food cost.
}

void Zoo::removesealion(int Idx){
    if ( n_sealions > 1 ) {
    	SeaLion* newsealions = new SeaLion[n_sealions-1];
        int j = 0;
    	for(int i = 0; i<n_sealions; i++) {
          	if ( i != Idx ) {
        		newsealions[j++] = sealions[i];
                n_sealions--;
            }
    	}
        sealions = newsealions;
    } else {
        n_sealions = 0;
    }
    if ( n_sealions > 1) {
        delete [] sealions;
    }  
}

void Zoo::removetiger(int Idx){
    if ( n_tigers > 1 ) {
    	Tiger* newtigers = new Tiger[n_tigers-1];
        int j = 0;
    	for(int i = 0; i<n_tigers; i++) {
          	if ( i != Idx ) {
        		newtigers[j++] = tigers[i];
                n_tigers--;
            }
    	}
        tigers = newtigers;
    } else {
        n_tigers = 0;
    }
    if ( n_tigers > 1) {
        delete [] tigers;
    }  
}

void Zoo::removebear(int Idx){
    if ( n_bears > 1 ) {
    	BlackBear* newbears = new BlackBear[n_bears-1];
        int j = 0;
    	for(int i = 0; i<n_bears; i++) {
          	if ( i != Idx ) {
        		newbears[j++] = bears[i];
                n_bears--;
            }
    	}
        bears = newbears;
    } else {
        n_bears = 0;
    }
    if ( n_bears > 1) {
        delete [] bears;
    }  
}

void Zoo::revenue() {
    for (int x = 0; x<n_sealions; x++) {
        int y = sealions[x].revenue();
        bank = bank + y;
    }
    for (int i = 0; i<n_tigers; i++) {
        int z = tigers[i].revenue();
        bank = bank + z;
    }
    for (int j = 0; j<n_bears; j++) {
        int k = bears[j].revenue();
        bank = bank + k;
    }
    if (n_adults >= 1 || n_babies >= 1 || n_teens>= 1) {
        cout << "You have made revenue from your animals! You now have $" << bank << " in your bank." << endl;
    } else {
        cout << "You have no animals and have generated no revenue." << endl;
    }
}

void Zoo::boom() {
    for (int x = 0; x<n_sealions; x++) {
        int y = sealions[x].extrarevenue();
        bank = bank + y;
    }
    cout << "You generated extra revenue and have $" << bank << " in your bank." << endl;
}

Zoo::~Zoo() {
  // cout << "Zoo Destructor" << endl;
    if (n_sealions)
        delete [] sealions;
    if (n_tigers)
        delete [] tigers;
    if (n_bears)
        delete [] bears;
}
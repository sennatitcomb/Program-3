/******************************************************
** Program: zoo_tycoon.cpp
** Author: Senna Titcomb
** Date: 05/09/2020
** Description: Write a zoo game program where a user manages a zoo with various animals (sea lions, tigers, and black bears).
** Player goal is to ensure animal welfare and gain profit. This is done by feeding animals and taking care of them when sick.	
** Input: the number of animals they wish to buy, the species of the animal they want to buy, and the decision to quit
** Output: the bank information, the number of adults and babies in each species, 
** the special event that occurs, the question of which species to buy, the number of animals to purchase and the choice to quit
******************************************************/

#include <iostream>
#include "animal.h"
#include "sealion.h"
#include "zoo.h"


using namespace std;

int main() {
    Zoo z1;
    cout << "Welcome to Zoo Tycoon." << endl;
    z1.playgame();

	return 0;
}
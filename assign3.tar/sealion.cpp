/*
	SeaLion Class
*/
#include <iostream>
#include "sealion.h"

using namespace std;

SeaLion::SeaLion() : Animal(){
  //  cout << "Default sealion constructor called" << endl;
    cost = 800;
    this->set_cost(cost);
    a.set_age(0);

}

SeaLion::SeaLion(double aAge) : Animal(aAge){
  //  cout << "Alternate sealion constructor called" << endl;
    cost = 800;
    this->set_cost(cost);
    a.set_age(aAge);
}

int SeaLion::sickcost() {
    if (a.isAdult()==true) { //IS ADULT
        return cost/2;
    } else if (a.isBaby() == true){ //IS BABY
        return cost;
    } else { //IS TEEN
        return cost/2;
    }
}

int SeaLion::revenue() {
    if (a.isAdult()== true) { //IS ADULT
        return 160;
    } else if (a.isBaby() == true){ //IS BABY
        return 320;
    } else { //IS TEEN
        return 160;
    }
}

int SeaLion::extrarevenue() {
    int x = rand()%250+150;
    return x;
}

/*************************************************************************************************************************************
** Function: Copy constructor
** Description: Tells program how to copy object
** Parameters: const Hand& old_deck
** Pre-conditions: const Hand& old_deck
** Post-conditions: none
*************************************************************************************************************************************/
/*SeaLion::SeaLion(const SeaLion& old_sl){
    cout << "Copy constructor!\n";
    this->n_cards = old_sl.n_cards;
    delete [] cards;
    cards = new Card[this->n_cards];
    for(int i = 0; i<n_cards; i++) {
        cards[i] = old_deck.cards[i];
    }
} */

/*************************************************************************************************************************************
** Function: Assignment Operator
** Description: Tells program how to copy object
** Parameters: const Hand& old_deck
** Pre-conditions: const Hand& old_deck
** Post-conditions: return *this
*************************************************************************************************************************************/
/*SeaLion& SeaLion::operator=(const SeaLion& old_deck){
    cout << "AOO!\n";
    if(this != &old_deck){
        delete [] cards;
        this-> n_cards = old_deck.n_cards;
        cards = new Card[this->n_cards];

        for(int i = 0; i<n_cards; i++) {
            cards[i] = old_deck.cards[i];
        }
    }
    return *this;
} 
*/

SeaLion::~SeaLion() {
   // cout << "Sealion Destructor" << endl;
} 
/*
	Tiger Class
*/
#include <iostream>
#include "tiger.h"

using namespace std;

Tiger::Tiger() : Animal(){
  //  cout << "Default sealion constructor called" << endl;
    cost = 15000;
    this->set_cost(cost);
    a.set_age(0);

}

Tiger::Tiger(double aAge) : Animal(aAge){
  //  cout << "Alternate sealion constructor called" << endl;
    cost = 15000;
    this->set_cost(cost);
    a.set_age(aAge);
}

int Tiger::sickcost() {
    if (a.isAdult()==true) { //IS ADULT
        return cost/2;
    } else if (a.isBaby() == true){ //IS BABY
        return cost;
    } else { //IS TEEN
        return cost/2;
    }
}

int Tiger::revenue() {
    if (a.isAdult()== true) { //IS ADULT
        return 1500;
    } else if (a.isBaby() == true){ //IS BABY
        return 3000;
    } else { //IS TEEN
        return 1500;
    }
}

Tiger::~Tiger() {
   // cout << "Tiger Destructor" << endl;
} 
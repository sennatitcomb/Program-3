/*
	Animal Class
*/
#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>
using namespace std;

class Animal {
public:
	Animal();
	Animal(double);
    ~Animal();
   // Animal(const Animal& old_animal);
   // Animal& operator= (const Animal&);
    //virtual Animal makeBaby() = 0;
    bool isAdult();
    bool isBaby();
    bool isTeen();
    int get_age();
    void set_age(int);
    int get_cost();
    void set_cost(int);
    int getmonth();
    void setmonth(int);
    void bump_age();

private:
    int n_babies;
    int month;
    double age;


protected:
	int cost; //derived class access, not main

};
#endif
/*
	Zoo Class
*/
#ifndef ZOO_H
#define ZOO_H

#include <iostream>
#include <string>
#include <stdio.h>     
#include <stdlib.h>     
#include <time.h>  
#include "animal.h"
#include "sealion.h"
#include "tiger.h"
#include "blackbear.h"

using namespace std;

class Zoo {
public:
	Zoo();
    ~Zoo();
    void playgame();
    void random();
    void buyanimals();
    void baby();
    int decreasemoney(int);
    void makesealion(int, double);
    bool checksadult();
    bool checktadult();
    bool checkbadult();
    void makebaby();
    void increaseage();
    void printlion();
    void feed();
    void userinfo();
    void removesealion(int);
    void sick();
    void sicklion();
    void sicktiger();
    void sickbear();
    void revenue();
    void boom();
    bool bankrupt();
    void maketiger(int, double);
    void makebear(int, double);
    void removetiger(int);
    void removebear(int);
    void printtiger();
    void printbear();
    void adults();
    void babies();
    void teens();
    void species(int);

private:
    int n_adults;
    int n_babies;
    int n_teens;
    int month;
    double bank;
    SeaLion* sealions;
    int n_sealions;
    Tiger* tigers;
    int n_tigers;
    BlackBear* bears;
    int n_bears;
    
};
#endif
/*
	BlackBear Class
*/
#ifndef BLACKBEAR_H
#define BLACKBEAR_H

#include <iostream>
#include "animal.h"

using namespace std;

class BlackBear : public Animal {
public:
	BlackBear();
    BlackBear(double);  //inherits age from animal
    int sickcost(); //determines cost after inheritance from animal
    int revenue();  //determines revenue after inheritance from animal
    ~BlackBear();
    Animal a;
    //Animal makeBaby();

private:
    int cost;
    static const int DEFAULT_ADULT_AGE = 4;
    static const int DEFAULT_BABY_AGE = 0;
    
};
#endif